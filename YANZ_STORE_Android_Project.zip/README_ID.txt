YANZ STORE - Proyek Android awal

ISI:
- Aplikasi Android WebView (Java)
- Tampilan toko demo: katalog akun/item game, keranjang, profil pelanggan
- Build APK otomatis melalui GitHub Actions

PENTING:
1. Produk dan harga di index.html adalah DATA CONTOH, bukan listing sungguhan.
2. Login saat ini belum memakai server/authentication. Profil hanya disimpan lokal di HP.
3. Checkout belum terhubung ke WhatsApp admin karena nomor toko belum diberikan.
4. Belum ada pembayaran online, verifikasi penjual, atau sistem escrow.
5. Jangan menjual akun/item yang melanggar aturan game atau berasal dari sumber tidak sah.
6. Ini APK debug untuk uji coba, belum APK rilis bertanda tangan.

CARA BUILD DARI HP:
1. Buat akun GitHub bila belum punya.
2. Buat repository baru bernama YANZ-STORE.
3. Upload seluruh isi ZIP ini ke repository (ekstrak ZIP terlebih dahulu).
4. Buka tab Actions, pilih workflow "Build YANZ STORE APK", lalu tekan Run workflow.
5. Setelah selesai, buka hasil run dan unduh artifact "YANZ-STORE-debug-apk".
6. Ekstrak artifact dan instal app-debug.apk. Android mungkin meminta izin instal aplikasi dari sumber ini.

Untuk rilis publik diperlukan signing key dan konfigurasi keamanan/backend.
